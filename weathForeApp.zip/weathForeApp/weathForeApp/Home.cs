﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace weathForeApp
{
    public partial class Home : Form
    {
        functionClass fClass = new functionClass();
        public Home()
        {
            InitializeComponent();
            //initializing grid columns       
            gridCity.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            fClass.dt_Load();

        }

        //Capturing data
        private void btnCap_Click(object sender, EventArgs e)
        {
            if (txtCity.Text!=null&&dateTime1.Text!=null&& txtMax.Text!=null && txtMin.Text!=null &&txtHumid.Text!=null && txtSpeed.Text!=null && txtPrecip.Text!=null &&
                txtCity.Text != "" && dateTime1.Text != "" && txtMax.Text != "" && txtMin.Text != "" && txtHumid.Text != "" && txtSpeed.Text != "" && txtPrecip.Text!=""
                )
            {
                fClass.capArr(txtCity.Text, dateTime1.Text, txtMax.Text, txtMin.Text, txtPrecip.Text, txtHumid.Text, txtSpeed.Text);
                MessageBox.Show("Weather forecast captured.");

            }
            else
            {
                MessageBox.Show("Enter all Datails");
            }
          
        }

        private void Home_Load(object sender, EventArgs e)
        {

        }

        private void btnCitySearch_Click(object sender, EventArgs e)
        {
            if (listRep.SelectedIndex==0)
            {

                gridCity.DataSource = fClass.Gen_cityReport(txtCitysearch.Text);
                fClass.Max_Temp(gridCity);
                fClass.Min_Temp(gridCity);

               
            }
        }

        private void btn_dateSearch_Click(object sender, EventArgs e)
        {
            if (listRep.SelectedIndex == 1) 
            {
                gridCity.DataSource = fClass.Gen_dateReport(dateTime_From, dateTime_To);
                fClass.Max_Temp(gridCity);
                fClass.Min_Temp(gridCity);
            }
        }
    }
}
