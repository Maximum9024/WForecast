﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace weathForeApp
{


    class functionClass
    {
        // array to store forecast data
        String[][] dataArray=new String[1000][];
        //Declaration of variables
        DataTable dt = new DataTable(" weatherforecast");
        int count = 0;

        //method to capture data
        public String[] capArr(String city,String date, String maxTemp, String minTemp, String precip, String humid, String windSpeed )
        {
           
                //each weather forecast
                String[] data =  { city, date, maxTemp, minTemp, precip, humid, windSpeed };

                dataArray[count] = data;
                count++;

            dt.Rows.Add(data);

                
           
            return data ;
           
        }

        //method to generate a report for a specific city
        public DataTable Gen_cityReport( String search)
        {
            string expression = "City = '"+search+"'";
            

            return dt.Select(expression).CopyToDataTable();
        }
        public DataTable Gen_dateReport(DateTimePicker From,DateTimePicker To)
        {
            string expression = "Date >=#'"+From+"'# AND Date<=#'"+To+"'#";

            return dt.Select(expression).CopyToDataTable();
        }
        
        //method to initialize the datatable
        public void dt_Load()
        {
            dt.Columns.Add("City", typeof(string));
            dt.Columns.Add("Date");
            dt.Columns.Add("Minimum temperature", typeof(int));
            dt.Columns.Add("Maximum temperature", typeof(int));
            dt.Columns.Add("Precipitation", typeof(int));
            dt.Columns.Add("Humidity", typeof(int));
            dt.Columns.Add("Wind speed", typeof(int));



        }

        //method to find the largest temperature in the table
        public void Max_Temp(DataGridView disp_data)

        {


            int max = 0;

            //finding the maximum value
            for (int i = 0; i < disp_data.Rows.Count; i++)
            {
                if (disp_data.Rows[i].Cells[3].Value != null)
                {
                    int temp = Int32.Parse(disp_data.Rows[i].Cells[3].Value.ToString());


                    if (max < temp)
                    {
                        max = temp;
                    }
                }

            }

            //setting the colour green for maximum temperature
            for (int i = 0; i < disp_data.Rows.Count; i++)
            {
                if (disp_data.Rows[i].Cells[3].Value != null)
                {
                    int temp = Int32.Parse(disp_data.Rows[i].Cells[3].Value.ToString());
                    if (temp == max)
                    {

                        disp_data.Rows[i].DefaultCellStyle.BackColor = Color.LightGreen;
                    }

                }
            }


        }

        public void Min_Temp(DataGridView disp_data)
        {
            int Min_value = 101;
            //finding the mainimum value
            for (int i = 0; i < disp_data.Rows.Count; i++)
            {
                if (disp_data.Rows[i].Cells[2].Value != null)
                {
                    int temp = Int32.Parse(disp_data.Rows[i].Cells[2].Value.ToString());


                    if (Min_value > temp)
                    {
                        Min_value = temp;
                    }
                }

            }

            //setting the colour green for minimum temperature
            for (int i = 0; i < disp_data.Rows.Count; i++)
            {
                if (disp_data.Rows[i].Cells[2].Value != null)
                {
                    int temp = Int32.Parse(disp_data.Rows[i].Cells[2].Value.ToString());
                    if (temp == Min_value)
                    {

                        disp_data.Rows[i].DefaultCellStyle.BackColor = Color.Yellow;
                    }

                }
            }


        }
    }
}
