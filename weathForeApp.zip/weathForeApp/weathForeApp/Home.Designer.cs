﻿namespace weathForeApp
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lblCity = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblmTemp = new System.Windows.Forms.Label();
            this.grpCapture = new System.Windows.Forms.GroupBox();
            this.dateTime1 = new System.Windows.Forms.DateTimePicker();
            this.btnCap = new System.Windows.Forms.Button();
            this.txtSpeed = new System.Windows.Forms.TextBox();
            this.txtHumid = new System.Windows.Forms.TextBox();
            this.txtPrecip = new System.Windows.Forms.TextBox();
            this.txtMax = new System.Windows.Forms.TextBox();
            this.txtMin = new System.Windows.Forms.TextBox();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.lblHumid = new System.Windows.Forms.Label();
            this.lblwSpeed = new System.Windows.Forms.Label();
            this.lblPrecip = new System.Windows.Forms.Label();
            this.grpGenRep = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_dateSearch = new System.Windows.Forms.Button();
            this.dateTime_To = new System.Windows.Forms.DateTimePicker();
            this.lbl_SearchDate = new System.Windows.Forms.Label();
            this.dateTime_From = new System.Windows.Forms.DateTimePicker();
            this.grpBoxCitysearch = new System.Windows.Forms.GroupBox();
            this.btnCitySearch = new System.Windows.Forms.Button();
            this.txtCitysearch = new System.Windows.Forms.TextBox();
            this.lbl_City = new System.Windows.Forms.Label();
            this.gridCity = new System.Windows.Forms.DataGridView();
            this.listRep = new System.Windows.Forms.ListBox();
            this.lblRepTyp = new System.Windows.Forms.Label();
            this.lblCap = new System.Windows.Forms.Label();
            this.lblGen = new System.Windows.Forms.Label();
            this.grpCapture.SuspendLayout();
            this.grpGenRep.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.grpBoxCitysearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridCity)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(415, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(246, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "Weather Forecast";
            // 
            // lblCity
            // 
            this.lblCity.AutoSize = true;
            this.lblCity.Location = new System.Drawing.Point(15, 31);
            this.lblCity.Name = "lblCity";
            this.lblCity.Size = new System.Drawing.Size(42, 16);
            this.lblCity.TabIndex = 1;
            this.lblCity.Text = "City: ";
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Location = new System.Drawing.Point(15, 71);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(46, 16);
            this.lblDate.TabIndex = 2;
            this.lblDate.Text = "Date :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 152);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 16);
            this.label4.TabIndex = 4;
            this.label4.Text = "Max Temp :";
            // 
            // lblmTemp
            // 
            this.lblmTemp.AutoSize = true;
            this.lblmTemp.Location = new System.Drawing.Point(15, 112);
            this.lblmTemp.Name = "lblmTemp";
            this.lblmTemp.Size = new System.Drawing.Size(75, 16);
            this.lblmTemp.TabIndex = 3;
            this.lblmTemp.Text = "Min Temp:";
            // 
            // grpCapture
            // 
            this.grpCapture.Controls.Add(this.dateTime1);
            this.grpCapture.Controls.Add(this.btnCap);
            this.grpCapture.Controls.Add(this.txtSpeed);
            this.grpCapture.Controls.Add(this.txtHumid);
            this.grpCapture.Controls.Add(this.txtPrecip);
            this.grpCapture.Controls.Add(this.txtMax);
            this.grpCapture.Controls.Add(this.txtMin);
            this.grpCapture.Controls.Add(this.txtCity);
            this.grpCapture.Controls.Add(this.lblHumid);
            this.grpCapture.Controls.Add(this.lblwSpeed);
            this.grpCapture.Controls.Add(this.lblPrecip);
            this.grpCapture.Controls.Add(this.lblmTemp);
            this.grpCapture.Controls.Add(this.label4);
            this.grpCapture.Controls.Add(this.lblCity);
            this.grpCapture.Controls.Add(this.lblDate);
            this.grpCapture.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpCapture.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.grpCapture.Location = new System.Drawing.Point(50, 184);
            this.grpCapture.Name = "grpCapture";
            this.grpCapture.Size = new System.Drawing.Size(276, 447);
            this.grpCapture.TabIndex = 5;
            this.grpCapture.TabStop = false;
            this.grpCapture.Text = "Capture Forecast";
            // 
            // dateTime1
            // 
            this.dateTime1.Location = new System.Drawing.Point(111, 64);
            this.dateTime1.Name = "dateTime1";
            this.dateTime1.Size = new System.Drawing.Size(102, 23);
            this.dateTime1.TabIndex = 16;
            // 
            // btnCap
            // 
            this.btnCap.AccessibleRole = System.Windows.Forms.AccessibleRole.Cursor;
            this.btnCap.BackColor = System.Drawing.SystemColors.Control;
            this.btnCap.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnCap.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnCap.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCap.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnCap.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btnCap.Location = new System.Drawing.Point(59, 317);
            this.btnCap.Name = "btnCap";
            this.btnCap.Size = new System.Drawing.Size(121, 51);
            this.btnCap.TabIndex = 15;
            this.btnCap.Text = "Capture";
            this.btnCap.UseVisualStyleBackColor = false;
            this.btnCap.Click += new System.EventHandler(this.btnCap_Click);
            // 
            // txtSpeed
            // 
            this.txtSpeed.BackColor = System.Drawing.Color.White;
            this.txtSpeed.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSpeed.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.txtSpeed.Location = new System.Drawing.Point(113, 268);
            this.txtSpeed.Name = "txtSpeed";
            this.txtSpeed.Size = new System.Drawing.Size(100, 16);
            this.txtSpeed.TabIndex = 14;
            // 
            // txtHumid
            // 
            this.txtHumid.BackColor = System.Drawing.Color.White;
            this.txtHumid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtHumid.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.txtHumid.Location = new System.Drawing.Point(111, 220);
            this.txtHumid.Name = "txtHumid";
            this.txtHumid.Size = new System.Drawing.Size(100, 16);
            this.txtHumid.TabIndex = 13;
            // 
            // txtPrecip
            // 
            this.txtPrecip.BackColor = System.Drawing.Color.White;
            this.txtPrecip.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPrecip.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.txtPrecip.Location = new System.Drawing.Point(111, 180);
            this.txtPrecip.Name = "txtPrecip";
            this.txtPrecip.Size = new System.Drawing.Size(100, 16);
            this.txtPrecip.TabIndex = 12;
            // 
            // txtMax
            // 
            this.txtMax.BackColor = System.Drawing.Color.White;
            this.txtMax.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtMax.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.txtMax.Location = new System.Drawing.Point(111, 145);
            this.txtMax.Name = "txtMax";
            this.txtMax.Size = new System.Drawing.Size(100, 16);
            this.txtMax.TabIndex = 11;
            // 
            // txtMin
            // 
            this.txtMin.BackColor = System.Drawing.Color.White;
            this.txtMin.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtMin.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.txtMin.Location = new System.Drawing.Point(111, 105);
            this.txtMin.Name = "txtMin";
            this.txtMin.Size = new System.Drawing.Size(100, 16);
            this.txtMin.TabIndex = 10;
            // 
            // txtCity
            // 
            this.txtCity.BackColor = System.Drawing.Color.White;
            this.txtCity.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCity.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.txtCity.Location = new System.Drawing.Point(111, 24);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(100, 16);
            this.txtCity.TabIndex = 8;
            // 
            // lblHumid
            // 
            this.lblHumid.AutoSize = true;
            this.lblHumid.Location = new System.Drawing.Point(15, 228);
            this.lblHumid.Name = "lblHumid";
            this.lblHumid.Size = new System.Drawing.Size(58, 16);
            this.lblHumid.TabIndex = 6;
            this.lblHumid.Text = "Humid :";
            // 
            // lblwSpeed
            // 
            this.lblwSpeed.AutoSize = true;
            this.lblwSpeed.Location = new System.Drawing.Point(15, 268);
            this.lblwSpeed.Name = "lblwSpeed";
            this.lblwSpeed.Size = new System.Drawing.Size(94, 16);
            this.lblwSpeed.TabIndex = 7;
            this.lblwSpeed.Text = "Wind Speed :";
            // 
            // lblPrecip
            // 
            this.lblPrecip.AutoSize = true;
            this.lblPrecip.Location = new System.Drawing.Point(15, 187);
            this.lblPrecip.Name = "lblPrecip";
            this.lblPrecip.Size = new System.Drawing.Size(90, 16);
            this.lblPrecip.TabIndex = 5;
            this.lblPrecip.Text = "Precipation :";
            // 
            // grpGenRep
            // 
            this.grpGenRep.Controls.Add(this.groupBox1);
            this.grpGenRep.Controls.Add(this.grpBoxCitysearch);
            this.grpGenRep.Controls.Add(this.gridCity);
            this.grpGenRep.Controls.Add(this.listRep);
            this.grpGenRep.Controls.Add(this.lblRepTyp);
            this.grpGenRep.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpGenRep.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.grpGenRep.Location = new System.Drawing.Point(380, 184);
            this.grpGenRep.Name = "grpGenRep";
            this.grpGenRep.Size = new System.Drawing.Size(788, 490);
            this.grpGenRep.TabIndex = 6;
            this.grpGenRep.TabStop = false;
            this.grpGenRep.Text = "Generate Report";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn_dateSearch);
            this.groupBox1.Controls.Add(this.dateTime_To);
            this.groupBox1.Controls.Add(this.lbl_SearchDate);
            this.groupBox1.Controls.Add(this.dateTime_From);
            this.groupBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.groupBox1.Location = new System.Drawing.Point(288, 71);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(475, 120);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Date Search";
            // 
            // btn_dateSearch
            // 
            this.btn_dateSearch.Location = new System.Drawing.Point(315, 62);
            this.btn_dateSearch.Name = "btn_dateSearch";
            this.btn_dateSearch.Size = new System.Drawing.Size(116, 48);
            this.btn_dateSearch.TabIndex = 6;
            this.btn_dateSearch.Text = "Search";
            this.btn_dateSearch.UseVisualStyleBackColor = true;
            this.btn_dateSearch.Click += new System.EventHandler(this.btn_dateSearch_Click);
            // 
            // dateTime_To
            // 
            this.dateTime_To.Location = new System.Drawing.Point(74, 91);
            this.dateTime_To.Name = "dateTime_To";
            this.dateTime_To.Size = new System.Drawing.Size(200, 23);
            this.dateTime_To.TabIndex = 4;
            // 
            // lbl_SearchDate
            // 
            this.lbl_SearchDate.AutoSize = true;
            this.lbl_SearchDate.Location = new System.Drawing.Point(17, 32);
            this.lbl_SearchDate.Name = "lbl_SearchDate";
            this.lbl_SearchDate.Size = new System.Drawing.Size(115, 16);
            this.lbl_SearchDate.TabIndex = 5;
            this.lbl_SearchDate.Text = "Search By Date :";
            // 
            // dateTime_From
            // 
            this.dateTime_From.Location = new System.Drawing.Point(74, 62);
            this.dateTime_From.Name = "dateTime_From";
            this.dateTime_From.Size = new System.Drawing.Size(200, 23);
            this.dateTime_From.TabIndex = 3;
            // 
            // grpBoxCitysearch
            // 
            this.grpBoxCitysearch.Controls.Add(this.btnCitySearch);
            this.grpBoxCitysearch.Controls.Add(this.txtCitysearch);
            this.grpBoxCitysearch.Controls.Add(this.lbl_City);
            this.grpBoxCitysearch.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.grpBoxCitysearch.Location = new System.Drawing.Point(23, 64);
            this.grpBoxCitysearch.Name = "grpBoxCitysearch";
            this.grpBoxCitysearch.Size = new System.Drawing.Size(258, 127);
            this.grpBoxCitysearch.TabIndex = 3;
            this.grpBoxCitysearch.TabStop = false;
            this.grpBoxCitysearch.Text = "City Search";
            // 
            // btnCitySearch
            // 
            this.btnCitySearch.Location = new System.Drawing.Point(128, 69);
            this.btnCitySearch.Name = "btnCitySearch";
            this.btnCitySearch.Size = new System.Drawing.Size(115, 41);
            this.btnCitySearch.TabIndex = 2;
            this.btnCitySearch.Text = "Search";
            this.btnCitySearch.UseVisualStyleBackColor = true;
            this.btnCitySearch.Click += new System.EventHandler(this.btnCitySearch_Click);
            // 
            // txtCitysearch
            // 
            this.txtCitysearch.Location = new System.Drawing.Point(94, 34);
            this.txtCitysearch.Name = "txtCitysearch";
            this.txtCitysearch.Size = new System.Drawing.Size(149, 23);
            this.txtCitysearch.TabIndex = 1;
            // 
            // lbl_City
            // 
            this.lbl_City.AutoSize = true;
            this.lbl_City.Location = new System.Drawing.Point(6, 41);
            this.lbl_City.Name = "lbl_City";
            this.lbl_City.Size = new System.Drawing.Size(91, 16);
            this.lbl_City.TabIndex = 0;
            this.lbl_City.Text = "Search City :";
            // 
            // gridCity
            // 
            this.gridCity.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridCity.Location = new System.Drawing.Point(23, 197);
            this.gridCity.Name = "gridCity";
            this.gridCity.Size = new System.Drawing.Size(759, 287);
            this.gridCity.TabIndex = 2;
            // 
            // listRep
            // 
            this.listRep.FormattingEnabled = true;
            this.listRep.ItemHeight = 16;
            this.listRep.Items.AddRange(new object[] {
            "Specific City",
            "Multiple Cities"});
            this.listRep.Location = new System.Drawing.Point(161, 33);
            this.listRep.Name = "listRep";
            this.listRep.Size = new System.Drawing.Size(145, 20);
            this.listRep.TabIndex = 1;
            // 
            // lblRepTyp
            // 
            this.lblRepTyp.AutoSize = true;
            this.lblRepTyp.Location = new System.Drawing.Point(20, 33);
            this.lblRepTyp.Name = "lblRepTyp";
            this.lblRepTyp.Size = new System.Drawing.Size(134, 16);
            this.lblRepTyp.TabIndex = 0;
            this.lblRepTyp.Text = "Select Report type :";
            // 
            // lblCap
            // 
            this.lblCap.AutoSize = true;
            this.lblCap.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCap.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lblCap.Location = new System.Drawing.Point(48, 134);
            this.lblCap.Name = "lblCap";
            this.lblCap.Size = new System.Drawing.Size(100, 24);
            this.lblCap.TabIndex = 7;
            this.lblCap.Text = "Capturing";
            // 
            // lblGen
            // 
            this.lblGen.AutoSize = true;
            this.lblGen.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGen.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.lblGen.Location = new System.Drawing.Point(376, 134);
            this.lblGen.Name = "lblGen";
            this.lblGen.Size = new System.Drawing.Size(101, 24);
            this.lblGen.TabIndex = 8;
            this.lblGen.Text = "Reporting";
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.ClientSize = new System.Drawing.Size(1216, 701);
            this.Controls.Add(this.lblGen);
            this.Controls.Add(this.lblCap);
            this.Controls.Add(this.grpGenRep);
            this.Controls.Add(this.grpCapture);
            this.Controls.Add(this.label1);
            this.Name = "Home";
            this.Text = "Weather forecast";
            this.Load += new System.EventHandler(this.Home_Load);
            this.grpCapture.ResumeLayout(false);
            this.grpCapture.PerformLayout();
            this.grpGenRep.ResumeLayout(false);
            this.grpGenRep.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.grpBoxCitysearch.ResumeLayout(false);
            this.grpBoxCitysearch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridCity)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblCity;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblmTemp;
        private System.Windows.Forms.GroupBox grpCapture;
        private System.Windows.Forms.Button btnCap;
        private System.Windows.Forms.TextBox txtSpeed;
        private System.Windows.Forms.TextBox txtHumid;
        private System.Windows.Forms.TextBox txtPrecip;
        private System.Windows.Forms.TextBox txtMax;
        private System.Windows.Forms.TextBox txtMin;
        private System.Windows.Forms.TextBox txtCity;
        private System.Windows.Forms.Label lblHumid;
        private System.Windows.Forms.Label lblwSpeed;
        private System.Windows.Forms.Label lblPrecip;
        private System.Windows.Forms.GroupBox grpGenRep;
        private System.Windows.Forms.ListBox listRep;
        private System.Windows.Forms.Label lblRepTyp;
        private System.Windows.Forms.Label lblCap;
        private System.Windows.Forms.Label lblGen;
        private System.Windows.Forms.DataGridView gridCity;
        private System.Windows.Forms.GroupBox grpBoxCitysearch;
        private System.Windows.Forms.Button btnCitySearch;
        private System.Windows.Forms.TextBox txtCitysearch;
        private System.Windows.Forms.Label lbl_City;
        private System.Windows.Forms.DateTimePicker dateTime1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_dateSearch;
        private System.Windows.Forms.DateTimePicker dateTime_To;
        private System.Windows.Forms.Label lbl_SearchDate;
        private System.Windows.Forms.DateTimePicker dateTime_From;
    }
}

